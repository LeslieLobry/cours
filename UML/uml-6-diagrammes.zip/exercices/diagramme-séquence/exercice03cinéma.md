### Exercice O3 : Réservation de places de cinéma via une application mobile

**Contexte :**
Un utilisateur souhaite réserver des places pour une séance de cinéma via une application mobile. Il sélectionne un film, choisit les sièges disponibles, effectue le paiement, et reçoit une confirmation de réservation. Si le paiement échoue, l'application propose de réessayer ou d'annuler la réservation.

**Objectif :**
Crée un diagramme de séquence représentant les interactions entre l’utilisateur, l’application mobile, le système de paiement et le serveur de la salle de cinéma. Le diagramme doit montrer les messages échangés pour la sélection des sièges, le traitement du paiement, ainsi que les actions de confirmation ou de gestion des erreurs en cas de paiement échoué.
