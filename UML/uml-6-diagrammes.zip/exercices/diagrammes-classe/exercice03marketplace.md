## **Exercice 03 : Marketplace de jeux vidéo dématérialisés**

### Sujet :

Concevez un diagramme de classes pour une marketplace de jeux vidéo numériques.

### Spécifications :

1. La plateforme propose des **jeux** à l’achat, chaque jeu ayant un **titre**, un **prix**, et un **éditeur**.
2. Les **utilisateurs** peuvent acheter des jeux, laisser des **avis** (note et commentaire) et télécharger les jeux achetés.
3. Chaque jeu appartient à une **catégorie** (action, aventure, etc.) et peut être développé par un ou plusieurs **studios**.
4. Les jeux peuvent également être vendus sous forme de **bundles** (paquets de jeux), permettant d’acheter plusieurs jeux à prix réduit.
5. Intégrez un système de **réductions** (e.g. ventes flash, promotions pour les membres premium).
6. Gérez les **transactions** avec des règles spécifiques, comme la **gestion des remboursements** sous certaines conditions (e.g. jeu joué moins de 2 heures).
